from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate

# LLM
llm = ChatGoogleGenerativeAI(
    model="models/gemini-pro-latest",  # ✅ use this
    temperature=0.7
)

# Prompt template
prompt = PromptTemplate(
    input_variables=["question"],
    template="""
You are PakFoodGPT 🇵🇰, an expert in Pakistani food.

Rules:
- Only Pakistani cuisine
- Answer in Urdu, Roman Urdu, or English
- Give authentic desi recipes
- Add cultural context when useful

User Question:
{question}
"""
)

# Chain
food_chain = prompt | llm
