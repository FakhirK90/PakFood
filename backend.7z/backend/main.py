from fastapi import FastAPI
from pydantic import BaseModel
from chains import food_chain

app = FastAPI(title="PakFoodGPT API")

class FoodQuery(BaseModel):
    query: str

@app.post("/ask")
def ask_food(data: FoodQuery):
    try:
        response = food_chain.invoke({"question": data.query})
        return {"answer": response.content}
    except Exception as e:
        return {
            "error": "Gemini processing failed",
            "details": str(e)
        }
