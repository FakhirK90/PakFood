import gradio as gr
import requests

API_URL = "http://127.0.0.1:8000/ask"

def chat_with_food_ai(message):
    response = requests.post(API_URL, json={"query": message})

    # DEBUG
    print("Status Code:", response.status_code)
    print("Raw Response:", response.text)

    if response.status_code != 200:
        return "❌ Backend error. Check FastAPI terminal."

    try:
        return response.json().get("answer", "❌ No answer key found")
    except Exception:
        return "❌ Invalid JSON response from backend"

gr.Interface(
    fn=chat_with_food_ai,
    inputs=gr.Textbox(label="Ask Pakistani Food"),
    outputs=gr.Textbox(label="Answer"),
    title="🇵🇰 PakFoodGPT"
).launch()
